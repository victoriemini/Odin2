PS Vita - Pegasus can't use vita3k's activity to launch a ROM because Vita3K does not use ROMs. Vita3K straight up installs games instead of loading up ROMs like normal emulators.

So I've included the code in the metadata and file to have an icon for the Vita3K emulator that you can open instead, just keep the vita.and file with the metadata and media folder.